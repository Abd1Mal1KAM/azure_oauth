# OAuth2 Authentication Script

-- This script handles OAuth2 authentication for a given service using the provided credentials and details. It authenticates a user by requesting their SERVICE, CLIENT_ID, CLIENT_SECRET, REDIRECT_URI, and optional SCOPES.

Make sure to download the folder and unzip into your downloads
